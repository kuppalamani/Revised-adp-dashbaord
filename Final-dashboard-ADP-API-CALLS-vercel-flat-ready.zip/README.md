# Aquera API Analytics Dashboard

React dashboard for tracking ADP API call volumes per tenant/connector, backed
by S3 + CloudFront. Admins upload an Excel file; the whole team just clicks
the link and sees the latest data.

## What's new in this version

### 1. Weekly Slack top-5 post (NEW)
An AWS Lambda runs on a schedule (default: **Mon 9 AM IST**), reads the same
`dashboard-data.json` from S3, computes the top 5 tenants by last-7-day calls,
and posts a formatted message with medals, WoW %, and 🚨 SPIKE badges to your
team's Slack channel. See [SETUP_SLACK.md](SETUP_SLACK.md).

### 2. Debug Guide page (NEW)
A new **Debug Guide** tab in the navbar contains a structured runbook for
investigating tenants making too many API calls. Edit
`src/components/DebugPage.jsx` — look for the `TODO:` markers and fill in
your team's specific debugging steps, log queries, escalation contacts, etc.

### 3. One-click upload for admins (NEW)
Previously admins had to generate a pre-signed S3 URL with the AWS CLI every
7 days and paste it into the dashboard. Now there's a small API Gateway +
Lambda that returns a fresh URL on demand, protected by an admin secret.
Admins just pick the Excel file and click Upload — done.

### 4. Anomaly detection
Tenants whose last-day API calls are ≥3× their prior 7-day average now show
a red 🚨 SPIKE badge on the main tenant table. The same flag is included
in the weekly Slack message.

### 5. Week-over-week column
New "WoW %" column on the tenant table shows last 7 days vs. previous 7 days —
green for decrease, red for increase.

### 6. CSV export
"Export CSV" buttons on both the main tenant table and the 7-day pivot table.

### 7. Shareable filtered links
All filter state (tenants, connectors, date range, email, current page) is
persisted in the URL. Copy the URL or click the new **Share** button in the
navbar to send a teammate a link that opens the exact same filtered view.

## Project layout

```
.
├── src/
│   ├── App.jsx                       ← main app, routing, URL sync
│   ├── components/
│   │   ├── DebugPage.jsx             ← NEW: runbook content
│   │   ├── TenantTable.jsx           ← now with spikes, WoW, export
│   │   ├── PivotTable.jsx            ← now with export
│   │   └── …everything else unchanged
│   └── utils/
│       ├── anomaly.js                ← NEW: spike + WoW calculators
│       ├── exportCsv.js              ← NEW: CSV helper
│       ├── s3DataService.js          ← updated: auto-upload flow
│       ├── auth.js                   ← hardcoded user list (unchanged)
│       └── dataProcessor.js          ← Excel parsing (unchanged)
├── lambda/
│   ├── weekly_slack_report.py        ← NEW: cron → Slack
│   ├── get_upload_url.py             ← NEW: admin upload endpoint
│   └── requirements.txt
├── .env                              ← fill in REACT_APP_* vars
├── SETUP_AWS.sh                      ← one-shot setup script
├── SETUP_SLACK.md                    ← Slack webhook walkthrough
└── README.md                         ← you are here
```

## First-time setup

1. **Create the Slack webhook** — follow [SETUP_SLACK.md](SETUP_SLACK.md)
   and copy the URL.
2. **Fill in the top of `SETUP_AWS.sh`**:
   - `YOUR_SITE_BUCKET` — your existing S3 bucket name
   - `YOUR_CLOUDFRONT_ID` / `YOUR_CLOUDFRONT_URL`
   - `SLACK_WEBHOOK_URL` — from step 1
3. **Run it:**
   ```bash
   bash SETUP_AWS.sh
   ```
   The script provisions both Lambdas, an API Gateway, and the EventBridge
   schedule. At the end it prints the three `REACT_APP_*` values.
4. **Paste those values into `.env`**, then rebuild + deploy the frontend:
   ```bash
   npm install
   npm run build
   aws s3 sync build/ s3://$YOUR_SITE_BUCKET --delete
   aws cloudfront create-invalidation --distribution-id $YOUR_CLOUDFRONT_ID --paths '/*'
   ```
5. **Fill in `src/components/DebugPage.jsx`** with your team's actual
   debugging content (search for `TODO:`).
6. **Test the Slack post manually** (don't wait until Monday):
   ```bash
   aws lambda invoke --function-name aquera-weekly-slack-report /tmp/out.json
   ```

## Adding / removing users

Edit `src/utils/auth.js` and rebuild the frontend.

## Running locally

```bash
npm install
npm start
```

The app opens at http://localhost:3000. With no `REACT_APP_S3_DATA_URL`
set, it runs in local-upload mode (admin uploads an Excel and the dashboard
loads locally, no S3 involved).
