#!/bin/bash
# ════════════════════════════════════════════════════════════════
#  AQURE DASHBOARD — FULL AWS SETUP
#  ───────────────────────────────────────────────────────────────
#  Sets up:
#   • S3 bucket with dashboard-data.json
#   • Lambda #1 — get_upload_url (admin clicks upload → gets URL)
#   • Lambda #2 — weekly_slack_report (Mon 9 AM IST → Slack top-5)
#   • API Gateway HTTP endpoint in front of Lambda #1
#   • EventBridge schedule for Lambda #2
#
#  PREREQUISITES: aws CLI configured (aws configure), jq installed
#
#  USAGE: Fill in the variables below, then run:
#         bash SETUP_AWS.sh
# ════════════════════════════════════════════════════════════════

set -e

# ── EDIT THESE ──────────────────────────────────────────────────
YOUR_SITE_BUCKET="aquera-dashboard-site"          # existing CloudFront-backed bucket
YOUR_CLOUDFRONT_ID="XXXXXXXXXXXXXX"
YOUR_CLOUDFRONT_URL="https://xxxxx.cloudfront.net"
REGION="us-east-1"
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# ── Slack + admin secret ────────────────────────────────────────
SLACK_WEBHOOK_URL="https://hooks.slack.com/services/XXXX/XXXX/XXXX"
ADMIN_SECRET="$(openssl rand -hex 24)"             # random — save this

# ── Cron schedule for the Slack post (UTC) ──────────────────────
# Monday 9 AM IST  = 03:30 UTC on Monday
# Monday 10 AM IST = 04:30 UTC on Monday
# Friday 5 PM IST  = 11:30 UTC on Friday
SLACK_CRON="cron(30 3 ? * MON *)"                # Mon 9 AM IST (default)
# ────────────────────────────────────────────────────────────────

echo ""
echo "════════════════════════════════════════════════════════"
echo "  AWS account: $AWS_ACCOUNT_ID   Region: $REGION"
echo "  Bucket:      $YOUR_SITE_BUCKET"
echo "  Admin secret (save this!):"
echo "  $ADMIN_SECRET"
echo "════════════════════════════════════════════════════════"
echo ""


# ════════════════════════════════════════════════════════════════
#  STEP 1: S3 bucket policy + placeholder data file
# ════════════════════════════════════════════════════════════════
echo "▸ Step 1: S3 bucket policy + placeholder data..."

aws s3api put-bucket-policy --bucket "$YOUR_SITE_BUCKET" --policy "{
  \"Version\": \"2012-10-17\",
  \"Statement\": [{
    \"Sid\": \"PublicReadDashboardSite\",
    \"Effect\": \"Allow\",
    \"Principal\": \"*\",
    \"Action\": \"s3:GetObject\",
    \"Resource\": \"arn:aws:s3:::$YOUR_SITE_BUCKET/*\"
  }]
}"

echo '{"records":[],"meta":{"status":"empty","uploadedAt":null}}' > /tmp/dashboard-data.json
aws s3 cp /tmp/dashboard-data.json "s3://$YOUR_SITE_BUCKET/dashboard-data.json" \
  --content-type "application/json"
echo "  ✓ Bucket policy set, placeholder data uploaded"


# ════════════════════════════════════════════════════════════════
#  STEP 2: IAM role shared by both Lambdas
# ════════════════════════════════════════════════════════════════
echo "▸ Step 2: IAM role for Lambdas..."

cat > /tmp/trust.json << 'EOF'
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": { "Service": "lambda.amazonaws.com" },
    "Action": "sts:AssumeRole"
  }]
}
EOF

aws iam create-role --role-name aquera-dashboard-lambda-role \
  --assume-role-policy-document file:///tmp/trust.json 2>/dev/null || echo "  (role exists)"

aws iam attach-role-policy --role-name aquera-dashboard-lambda-role \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

cat > /tmp/s3-policy.json << EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["s3:GetObject", "s3:PutObject"],
    "Resource": "arn:aws:s3:::$YOUR_SITE_BUCKET/dashboard-data.json"
  }]
}
EOF

aws iam put-role-policy --role-name aquera-dashboard-lambda-role \
  --policy-name aquera-dashboard-s3-access \
  --policy-document file:///tmp/s3-policy.json

echo "  ✓ IAM role ready (waiting 10s for propagation...)"
sleep 10

LAMBDA_ROLE_ARN="arn:aws:iam::$AWS_ACCOUNT_ID:role/aquera-dashboard-lambda-role"


# ════════════════════════════════════════════════════════════════
#  STEP 3: Package + deploy Lambda #1 — get_upload_url
# ════════════════════════════════════════════════════════════════
echo "▸ Step 3: Deploying get_upload_url Lambda..."

cd lambda
zip -q get_upload_url.zip get_upload_url.py

aws lambda create-function \
  --function-name aquera-get-upload-url \
  --runtime python3.11 \
  --handler get_upload_url.lambda_handler \
  --role "$LAMBDA_ROLE_ARN" \
  --zip-file fileb://get_upload_url.zip \
  --timeout 10 \
  --region "$REGION" \
  --environment "Variables={S3_BUCKET=$YOUR_SITE_BUCKET,S3_KEY=dashboard-data.json,ADMIN_SECRET=$ADMIN_SECRET,CORS_ORIGIN=$YOUR_CLOUDFRONT_URL}" \
  2>/dev/null || \
aws lambda update-function-code \
  --function-name aquera-get-upload-url \
  --zip-file fileb://get_upload_url.zip \
  --region "$REGION"

aws lambda update-function-configuration \
  --function-name aquera-get-upload-url \
  --environment "Variables={S3_BUCKET=$YOUR_SITE_BUCKET,S3_KEY=dashboard-data.json,ADMIN_SECRET=$ADMIN_SECRET,CORS_ORIGIN=$YOUR_CLOUDFRONT_URL}" \
  --region "$REGION" > /dev/null

echo "  ✓ aquera-get-upload-url deployed"


# Create HTTP API Gateway in front of it
echo "▸ Creating API Gateway for get_upload_url..."
API_ID=$(aws apigatewayv2 create-api \
  --name aquera-get-upload-url-api \
  --protocol-type HTTP \
  --target "arn:aws:lambda:$REGION:$AWS_ACCOUNT_ID:function:aquera-get-upload-url" \
  --cors-configuration "AllowOrigins=$YOUR_CLOUDFRONT_URL,AllowMethods=POST,OPTIONS,AllowHeaders=Content-Type,X-Admin-Secret" \
  --region "$REGION" \
  --query ApiId --output text 2>/dev/null || \
  aws apigatewayv2 get-apis --region "$REGION" \
    --query "Items[?Name=='aquera-get-upload-url-api'].ApiId" --output text)

API_ENDPOINT="https://$API_ID.execute-api.$REGION.amazonaws.com"

aws lambda add-permission \
  --function-name aquera-get-upload-url \
  --statement-id apigateway-invoke \
  --action lambda:InvokeFunction \
  --principal apigateway.amazonaws.com \
  --source-arn "arn:aws:execute-api:$REGION:$AWS_ACCOUNT_ID:$API_ID/*/*" \
  --region "$REGION" 2>/dev/null || echo "  (permission exists)"

echo "  ✓ API endpoint: $API_ENDPOINT"


# ════════════════════════════════════════════════════════════════
#  STEP 4: Package + deploy Lambda #2 — weekly_slack_report
# ════════════════════════════════════════════════════════════════
echo "▸ Step 4: Deploying weekly_slack_report Lambda..."

zip -q weekly_slack_report.zip weekly_slack_report.py

aws lambda create-function \
  --function-name aquera-weekly-slack-report \
  --runtime python3.11 \
  --handler weekly_slack_report.lambda_handler \
  --role "$LAMBDA_ROLE_ARN" \
  --zip-file fileb://weekly_slack_report.zip \
  --timeout 30 \
  --region "$REGION" \
  --environment "Variables={S3_BUCKET=$YOUR_SITE_BUCKET,S3_KEY=dashboard-data.json,SLACK_WEBHOOK_URL=$SLACK_WEBHOOK_URL,DASHBOARD_URL=$YOUR_CLOUDFRONT_URL,SPIKE_THRESHOLD=3.0}" \
  2>/dev/null || \
aws lambda update-function-code \
  --function-name aquera-weekly-slack-report \
  --zip-file fileb://weekly_slack_report.zip \
  --region "$REGION"

aws lambda update-function-configuration \
  --function-name aquera-weekly-slack-report \
  --environment "Variables={S3_BUCKET=$YOUR_SITE_BUCKET,S3_KEY=dashboard-data.json,SLACK_WEBHOOK_URL=$SLACK_WEBHOOK_URL,DASHBOARD_URL=$YOUR_CLOUDFRONT_URL,SPIKE_THRESHOLD=3.0}" \
  --region "$REGION" > /dev/null

echo "  ✓ aquera-weekly-slack-report deployed"

cd ..


# ════════════════════════════════════════════════════════════════
#  STEP 5: EventBridge schedule for weekly Slack post
# ════════════════════════════════════════════════════════════════
echo "▸ Step 5: EventBridge schedule ($SLACK_CRON)..."

aws events put-rule \
  --name aquera-weekly-slack-schedule \
  --schedule-expression "$SLACK_CRON" \
  --region "$REGION" > /dev/null

aws lambda add-permission \
  --function-name aquera-weekly-slack-report \
  --statement-id eventbridge-invoke \
  --action lambda:InvokeFunction \
  --principal events.amazonaws.com \
  --source-arn "arn:aws:events:$REGION:$AWS_ACCOUNT_ID:rule/aquera-weekly-slack-schedule" \
  --region "$REGION" 2>/dev/null || echo "  (permission exists)"

aws events put-targets \
  --rule aquera-weekly-slack-schedule \
  --targets "Id=1,Arn=arn:aws:lambda:$REGION:$AWS_ACCOUNT_ID:function:aquera-weekly-slack-report" \
  --region "$REGION" > /dev/null

echo "  ✓ Schedule active — next run based on cron: $SLACK_CRON"


# ════════════════════════════════════════════════════════════════
#  STEP 6: Write .env values + remind to rebuild
# ════════════════════════════════════════════════════════════════
echo ""
echo "════════════════════════════════════════════════════════════"
echo "  ✅  Setup complete!"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "  Put these in your .env file, then 'npm run build':"
echo ""
echo "    REACT_APP_S3_DATA_URL=$YOUR_CLOUDFRONT_URL/dashboard-data.json"
echo "    REACT_APP_UPLOAD_URL_ENDPOINT=$API_ENDPOINT"
echo "    REACT_APP_ADMIN_SECRET=$ADMIN_SECRET"
echo ""
echo "  Then deploy the frontend:"
echo "    cd .. && npm run build"
echo "    aws s3 sync build/ s3://$YOUR_SITE_BUCKET --delete"
echo "    aws cloudfront create-invalidation --distribution-id $YOUR_CLOUDFRONT_ID --paths '/*'"
echo ""
echo "  TEST THE SLACK POST MANUALLY:"
echo "    aws lambda invoke --function-name aquera-weekly-slack-report /tmp/out.json"
echo "    cat /tmp/out.json"
echo ""
echo "  CHANGE THE SCHEDULE LATER:"
echo "    aws events put-rule --name aquera-weekly-slack-schedule \\"
echo "       --schedule-expression 'cron(30 4 ? * MON *)'   # Mon 10 AM IST"
echo ""
echo "════════════════════════════════════════════════════════════"
