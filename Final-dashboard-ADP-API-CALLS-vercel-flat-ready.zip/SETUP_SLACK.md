# Slack Setup — Weekly Top-5 Tenants

This guide walks you through creating a Slack **Incoming Webhook** so the
`aquera-weekly-slack-report` Lambda can post the weekly top-5 tenants to your
team channel.

You only need to do this **once**.

---

## 1. Create a Slack app

1. Open https://api.slack.com/apps and click **Create New App**.
2. Choose **From scratch**.
3. **App Name:** `Aquera API Analytics`
4. **Workspace:** pick your team's workspace.
5. Click **Create App**.

## 2. Enable Incoming Webhooks

1. In the left sidebar, click **Incoming Webhooks**.
2. Flip the **Activate Incoming Webhooks** toggle to **On**.
3. Scroll down and click **Add New Webhook to Workspace**.
4. Pick the channel where you want the weekly post to land — e.g.
   `#sre-api-usage` or `#team-aquera`.
5. Click **Allow**.
6. Back on the Incoming Webhooks page, copy the **Webhook URL**. It looks like:

   ```
   https://hooks.slack.com/services/T0XXXXX/B0XXXXX/abc123def456…
   ```

   **Save it somewhere safe.** Anyone with this URL can post to your channel.

## 3. Plug the URL into AWS

Open `SETUP_AWS.sh` and paste the webhook into the `SLACK_WEBHOOK_URL`
variable near the top:

```bash
SLACK_WEBHOOK_URL="https://hooks.slack.com/services/T0XXXXX/B0XXXXX/abc123..."
```

Then run the setup script:

```bash
bash SETUP_AWS.sh
```

The script creates the Lambda with this webhook baked in as an environment variable.

## 4. Test immediately (don't wait for Monday)

After setup, invoke the Lambda manually to confirm the message reaches Slack:

```bash
aws lambda invoke \
  --function-name aquera-weekly-slack-report \
  /tmp/out.json
cat /tmp/out.json
```

You should see a message in your chosen Slack channel within seconds.

If nothing arrives:

- Check the Lambda's CloudWatch logs: `/aws/lambda/aquera-weekly-slack-report`
- Verify the webhook URL is correct (no trailing spaces, exactly what Slack gave you)
- Confirm `dashboard-data.json` has records — if it's still the empty placeholder,
  the bot will post a "no data" notice instead of top-5

## 5. Change the channel later

To redirect the post to a different channel:

1. Go back to https://api.slack.com/apps → your app → **Incoming Webhooks**
2. Click **Add New Webhook to Workspace**, pick the new channel, copy the new URL
3. Update the Lambda env var:

   ```bash
   aws lambda update-function-configuration \
     --function-name aquera-weekly-slack-report \
     --environment "Variables={S3_BUCKET=...,S3_KEY=...,SLACK_WEBHOOK_URL=<NEW_URL>,DASHBOARD_URL=...,SPIKE_THRESHOLD=3.0}"
   ```

## 6. Change the schedule

The default is **Monday 9 AM IST** (cron: `cron(30 3 ? * MON *)` in UTC).

A few common alternatives:

| When            | Cron expression (UTC)      |
| --------------- | -------------------------- |
| Mon 10 AM IST   | `cron(30 4 ? * MON *)`     |
| Fri 5 PM IST    | `cron(30 11 ? * FRI *)`    |
| Mon & Fri 9 AM  | `cron(30 3 ? * MON,FRI *)` |
| Every weekday   | `cron(30 3 ? * MON-FRI *)` |

Update it:

```bash
aws events put-rule --name aquera-weekly-slack-schedule \
  --schedule-expression 'cron(30 4 ? * MON *)'
```

## What the message looks like

```
📊 Weekly API Calls — Top 5 Tenants

🥇  Acme Corp    — 2.34M calls  (+18% WoW) 🚨 SPIKE
🥈  Globex Ltd   — 1.87M calls  (+4% WoW)
🥉  Initech      — 1.22M calls  (-12% WoW)
4️⃣  Umbrella     — 980.5K calls (flat WoW)
5️⃣  Soylent      — 740.0K calls (new)

Period: 2026-04-14 → 2026-04-20 · Data last refreshed: 2026-04-20
[ Open Dashboard → ]
```

The 🚨 SPIKE badge appears when a tenant's last 7 days are **3× or more** than
their prior 7 days. Tweak the threshold via the `SPIKE_THRESHOLD` env var on
the Lambda.
