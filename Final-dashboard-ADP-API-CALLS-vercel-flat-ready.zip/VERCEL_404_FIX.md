# Vercel 404 NOT_FOUND Fix

This project must be deployed with this directory as the Vercel project root.
At the project root Vercel must see:

- package.json
- package-lock.json
- vercel.json
- public/
- src/

Recommended Vercel settings:

- Framework Preset: Create React App
- Root Directory: leave blank when this folder is the repository root
- Build Command: npm run build
- Output Directory: build
- Install Command: npm install (or npm ci)

If GitHub contains an extra parent folder, set Vercel Root Directory to the folder that contains package.json.
After changing settings, redeploy without using the previous build cache.
