# Vercel deployment

This revision fixes the ESLint warnings that caused Create React App to fail in Vercel CI.

## Deploy

1. Push this project to GitHub.
2. Import the repository in Vercel.
3. Framework preset: Create React App.
4. Build command: `npm run build`
5. Output directory: `build`
6. Install command: `npm install` (Vercel can also use the lock file automatically).

`vercel.json` already contains the build and SPA rewrite configuration.

## Optional environment variables

Configure only the variables required by your deployment:

- `REACT_APP_S3_DATA_URL`
- `REACT_APP_UPLOAD_URL_ENDPOINT`
- `REACT_APP_ADMIN_SECRET`
- `REACT_APP_API_URL`

After changing a `REACT_APP_*` variable, redeploy because Create React App embeds these values at build time.

## Security note

Anything prefixed with `REACT_APP_` is included in the browser bundle and is visible to users. Do not treat `REACT_APP_ADMIN_SECRET` as a confidential production secret. For production, move secret-bearing requests behind a server-side API or Vercel Function and keep the secret in a server-only environment variable.

## Fixed CI errors

- Removed unused `WelcomePage` import from `src/App.jsx`.
- Made `GreetingModal.handleClose` stable with `useCallback` and added it to the `useEffect` dependencies.
- Memoized `Heatmap` tenant initialization so the `useMemo` dependency remains stable.
- Removed unused `BarChart` and `Bar` imports from `TrendChart.jsx`.
