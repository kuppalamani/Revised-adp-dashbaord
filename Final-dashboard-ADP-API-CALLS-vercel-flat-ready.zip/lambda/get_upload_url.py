"""
Presigned-URL Generator for Admin Uploads
==========================================
Returns a short-lived pre-signed PUT URL for dashboard-data.json in S3.
The frontend calls this instead of requiring the admin to manually
generate a URL with the AWS CLI every 7 days.

Endpoint: POST /get-upload-url
Headers:  X-Admin-Secret: <shared secret>
Body:     (none)
Returns:  { "url": "https://s3...", "expiresIn": 900 }

Environment variables:
  S3_BUCKET       — e.g. "aquera-dashboard-site"
  S3_KEY          — e.g. "dashboard-data.json"
  ADMIN_SECRET    — shared secret string; frontend sends it in header
  CORS_ORIGIN     — e.g. "https://xxxxx.cloudfront.net" (or "*" for dev)
"""

import json
import os

import boto3

s3 = boto3.client("s3")


def _cors_headers():
    origin = os.environ.get("CORS_ORIGIN", "*")
    return {
        "Access-Control-Allow-Origin": origin,
        "Access-Control-Allow-Headers": "Content-Type,X-Admin-Secret",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
        "Content-Type": "application/json",
    }


def _response(status, body):
    return {
        "statusCode": status,
        "headers": _cors_headers(),
        "body": json.dumps(body),
    }


def lambda_handler(event, context):
    method = (event.get("requestContext", {}).get("http", {}).get("method")
              or event.get("httpMethod") or "").upper()

    # CORS preflight
    if method == "OPTIONS":
        return _response(204, {})

    if method != "POST":
        return _response(405, {"error": "Method not allowed"})

    # Auth check — shared secret in header
    headers = {k.lower(): v for k, v in (event.get("headers") or {}).items()}
    provided = headers.get("x-admin-secret", "")
    expected = os.environ.get("ADMIN_SECRET", "")
    if not expected or provided != expected:
        return _response(401, {"error": "Unauthorized"})

    bucket = os.environ["S3_BUCKET"]
    key = os.environ["S3_KEY"]

    try:
        url = s3.generate_presigned_url(
            ClientMethod="put_object",
            Params={
                "Bucket": bucket,
                "Key": key,
                "ContentType": "application/json",
            },
            ExpiresIn=900,  # 15 minutes — plenty for an upload
        )
        return _response(200, {"url": url, "expiresIn": 900})
    except Exception as e:
        return _response(500, {"error": f"Failed to generate URL: {type(e).__name__}"})
