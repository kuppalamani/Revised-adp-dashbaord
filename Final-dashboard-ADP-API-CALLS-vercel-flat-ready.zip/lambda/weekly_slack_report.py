"""
Weekly Slack Top-5 Tenants Report
==================================
Reads dashboard-data.json from S3, computes the top 5 tenants by API calls
over the last 7 days, and posts a formatted message to Slack via webhook.

Runs on EventBridge schedule (default: Mondays 9 AM IST = 03:30 UTC).

Environment variables (set in Lambda console):
  S3_BUCKET           — e.g. "aquera-dashboard-site"
  S3_KEY              — e.g. "dashboard-data.json"
  SLACK_WEBHOOK_URL   — https://hooks.slack.com/services/T.../B.../...
  DASHBOARD_URL       — e.g. "https://xxxxx.cloudfront.net" (optional, adds a link)
  SPIKE_THRESHOLD     — float, default "3.0" (flag tenants whose calls are
                        >Nx their prior 7-day average)
"""

import json
import os
import urllib.request
from collections import defaultdict
from datetime import datetime

import boto3

s3 = boto3.client("s3")


def _load_records():
    bucket = os.environ["S3_BUCKET"]
    key = os.environ["S3_KEY"]
    obj = s3.get_object(Bucket=bucket, Key=key)
    body = json.loads(obj["Body"].read())
    records = body.get("records", [])
    meta = body.get("meta", {})
    return records, meta


def _compute_top_tenants(records, n=5):
    """
    Returns (top_tenants, period_info) where:
      top_tenants = [{name, calls, wow_pct, is_spike}, ...] sorted desc
      period_info = {"last7": [iso_date,...], "prev7": [...]}
    """
    if not records:
        return [], {"last7": [], "prev7": []}

    all_dates = sorted({r["date"] for r in records})
    last7 = all_dates[-7:]
    prev7 = all_dates[-14:-7] if len(all_dates) >= 14 else []

    last7_set = set(last7)
    prev7_set = set(prev7)

    last7_totals = defaultdict(int)
    prev7_totals = defaultdict(int)

    for r in records:
        tn = (r.get("tenantName") or "").strip()
        if not tn:
            continue
        calls = r.get("calls", 0) or 0
        if r["date"] in last7_set:
            last7_totals[tn] += calls
        elif r["date"] in prev7_set:
            prev7_totals[tn] += calls

    spike_threshold = float(os.environ.get("SPIKE_THRESHOLD", "3.0"))
    rows = []
    for tn, cur in last7_totals.items():
        prev = prev7_totals.get(tn, 0)
        if prev > 0:
            wow_pct = round(((cur - prev) / prev) * 100)
            is_spike = cur >= prev * spike_threshold
        else:
            wow_pct = None
            is_spike = False
        rows.append({"name": tn, "calls": cur, "wow_pct": wow_pct, "is_spike": is_spike})

    rows.sort(key=lambda r: r["calls"], reverse=True)
    return rows[:n], {"last7": last7, "prev7": prev7}


def _format_number(n):
    if n >= 1_000_000:
        return f"{n/1_000_000:.2f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)


def _build_slack_message(top, period_info, meta):
    dashboard_url = os.environ.get("DASHBOARD_URL", "").rstrip("/")
    last7 = period_info["last7"]
    if last7:
        period_label = f"{last7[0]} → {last7[-1]}"
    else:
        period_label = "—"

    medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"]

    if not top:
        blocks = [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": "📊 Weekly API Calls — Top Tenants"},
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "No data available in S3 yet. Please upload the weekly Excel to the dashboard.",
                },
            },
        ]
        return {"blocks": blocks, "text": "Weekly API Calls — no data"}

    # Build the tenant lines
    lines = []
    for i, t in enumerate(top):
        medal = medals[i] if i < len(medals) else f"{i+1}."
        calls_str = _format_number(t["calls"])
        if t["wow_pct"] is None:
            wow_str = "_new_"
        elif t["wow_pct"] > 0:
            wow_str = f"+{t['wow_pct']}% WoW"
        elif t["wow_pct"] < 0:
            wow_str = f"{t['wow_pct']}% WoW"
        else:
            wow_str = "flat WoW"
        spike = " 🚨 *SPIKE*" if t["is_spike"] else ""
        lines.append(f"{medal}  *{t['name']}*  —  `{calls_str}` calls  ({wow_str}){spike}")

    body_text = "\n".join(lines)

    footer_bits = [f"Period: {period_label}"]
    if meta.get("uploadedAt"):
        footer_bits.append(f"Data last refreshed: {meta['uploadedAt'][:10]}")

    blocks = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": "📊 Weekly API Calls — Top 5 Tenants"},
        },
        {"type": "section", "text": {"type": "mrkdwn", "text": body_text}},
        {
            "type": "context",
            "elements": [{"type": "mrkdwn", "text": " · ".join(footer_bits)}],
        },
    ]

    if dashboard_url:
        blocks.append(
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "Open Dashboard →"},
                        "url": dashboard_url,
                        "style": "primary",
                    }
                ],
            }
        )

    # Fallback text for notifications / mobile previews
    fallback = "Weekly API Top 5: " + ", ".join(
        f"{t['name']} ({_format_number(t['calls'])})" for t in top
    )

    return {"blocks": blocks, "text": fallback}


def _post_to_slack(payload):
    webhook = os.environ["SLACK_WEBHOOK_URL"]
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        webhook,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        if resp.status != 200:
            raise RuntimeError(f"Slack webhook returned {resp.status}")


def lambda_handler(event, context):
    try:
        records, meta = _load_records()
        top, period_info = _compute_top_tenants(records, n=5)
        payload = _build_slack_message(top, period_info, meta)
        _post_to_slack(payload)
        return {
            "statusCode": 200,
            "body": json.dumps(
                {"ok": True, "tenants_posted": len(top), "period": period_info["last7"]}
            ),
        }
    except Exception as e:
        # Post error to Slack too so the team notices silent failures
        try:
            webhook = os.environ.get("SLACK_WEBHOOK_URL")
            if webhook:
                err_payload = {
                    "text": f"⚠️ Weekly API report failed: `{type(e).__name__}: {e}`"
                }
                urllib.request.urlopen(
                    urllib.request.Request(
                        webhook,
                        data=json.dumps(err_payload).encode("utf-8"),
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    ),
                    timeout=10,
                )
        except Exception:
            pass
        raise
