import React, { useState, useMemo, useCallback, useEffect } from "react";
import LoginPage       from "./components/LoginPage";
import GreetingModal   from "./components/GreetingModal";
import Sidebar         from "./components/Sidebar";
import KPICards        from "./components/KPICards";
import ChartCard       from "./components/ChartCard";
import Heatmap         from "./components/Heatmap";
import TrendChart      from "./components/TrendChart";
import BreakdownCharts from "./components/BreakdownCharts";
import Last5Days       from "./components/Last5Days";
import TenantTable     from "./components/TenantTable";
import ConnectorTicker from "./components/ConnectorTicker";
import PivotTable      from "./components/PivotTable";
import MonthlyGraphs   from "./components/MonthlyGraphs";
import DebugPage       from "./components/DebugPage";
import { LogOut, LayoutDashboard, Table2, BarChart2, RefreshCw, Upload, Cloud, LifeBuoy, Share2 } from "lucide-react";
import {
  parseExcelFile, computeKPIs, getLastDayCalls, getLastNDaysCalls,
  getDailyTrend, getMonthlyTrend, getTopTenants, getTopConnectors,
  getHeatmapData, getUniqueTenants, getUniqueConnectors, getTenantTable,
  getLast7DaysPivot, getMonthlyGraphData, getLast7DaysConnectors,
} from "./utils/dataProcessor";
import { getTenantSpikes, getTenantWoW } from "./utils/anomaly";
import { getSession, logout } from "./utils/auth";
import { fetchSharedData, uploadDataToS3, isS3Mode, hasAutoUpload, requestUploadUrl } from "./utils/s3DataService";

/* ─── URL-filter helpers ──────────────────────────────────────── */
function readFiltersFromUrl() {
  try {
    const q = new URLSearchParams(window.location.search);
    return {
      tenants: q.get("tenants") ? q.get("tenants").split("|").filter(Boolean) : [],
      connectors: q.get("connectors") ? q.get("connectors").split("|").filter(Boolean) : [],
      email: q.get("email") || "",
      start: q.get("start") || "",
      end: q.get("end") || "",
      page: q.get("page") || "dashboard",
    };
  } catch { return { tenants:[], connectors:[], email:"", start:"", end:"", page:"dashboard" }; }
}
function writeFiltersToUrl({ tenants, connectors, email, start, end, page }) {
  const q = new URLSearchParams();
  if (tenants?.length)    q.set("tenants",    tenants.join("|"));
  if (connectors?.length) q.set("connectors", connectors.join("|"));
  if (email)              q.set("email",      email);
  if (start)              q.set("start",      start);
  if (end)                q.set("end",        end);
  if (page && page !== "dashboard") q.set("page", page);
  const qs = q.toString();
  const url = qs ? `${window.location.pathname}?${qs}` : window.location.pathname;
  window.history.replaceState(null, "", url);
}

/* ─── Root ────────────────────────────────────────────────────── */
export default function App() {
  const [session,      setSession]      = useState(() => getSession());
  const [showGreeting, setShowGreeting] = useState(false);

  if (!session) {
    return <LoginPage onLogin={(u) => { setSession(u); setShowGreeting(true); }} />;
  }
  return (
    <>
      {showGreeting && <GreetingModal session={session} onClose={() => setShowGreeting(false)} />}
      <MainApp session={session} onLogout={() => { logout(); setSession(null); }} />
    </>
  );
}

/* ─── MainApp ─────────────────────────────────────────────────── */
function MainApp({ session, onLogout }) {
  const initial = readFiltersFromUrl();

  const [rawData,     setRawData]     = useState(null);
  const [uploadInfo,  setUploadInfo]  = useState(null);
  const [status,      setStatus]      = useState("idle"); // idle|loading|error|ready|no_data
  const [error,       setError]       = useState(null);

  const [selTenants,    setSelTenants]    = useState(initial.tenants);
  const [selConnectors, setSelConnectors] = useState(initial.connectors);
  const [emailSearch,   setEmailSearch]   = useState(initial.email);
  const [dateRange,     setDateRange]     = useState({ start: initial.start, end: initial.end });

  /* Auto-fetch shared data from S3 on mount (cloud mode) */
  const fetchFromS3 = useCallback(async () => {
    if (!isS3Mode) return;
    setStatus("loading"); setError(null);
    try {
      const json = await fetchSharedData();
      setRawData(json.records);
      setUploadInfo({ ...json.meta, cloudMode:true, name: json.meta?.sheetName ?? "Shared Data" });
      setStatus("ready");
    } catch (e) {
      if (e.message === "NO_DATA") {
        setStatus("no_data");
      } else {
        setStatus("error"); setError(e.message);
      }
    }
  }, []);

  useEffect(() => { fetchFromS3(); }, [fetchFromS3]);

  /* Parse local Excel and push to S3 (admin only) */
  const handleUpload = useCallback(async (file, presignedUrl) => {
    setStatus("loading"); setError(null);
    try {
      const result = await parseExcelFile({ target:{ files:[file] } });
      setRawData(result.data);
      const meta = { sheetName:file.name, totalRows:result.totalRows, dateColsCount:result.dateColsCount, lastDate:result.allDates?.[result.allDates.length-1]??"—" };
      setUploadInfo({ ...meta, cloudMode: isS3Mode });

      if (isS3Mode) {
        // Prefer auto-upload (fetch fresh presigned URL from Lambda);
        // fall back to manually-pasted URL if Lambda not configured.
        let urlToUse = presignedUrl;
        if (!urlToUse && hasAutoUpload) {
          urlToUse = await requestUploadUrl();
        }
        if (urlToUse) {
          await uploadDataToS3(result.data, meta, urlToUse);
          setUploadInfo(prev => ({ ...prev, uploadedToS3:true, uploadedAt:new Date().toISOString() }));
        }
      }
      setStatus("ready");
    } catch (e) {
      setStatus("error"); setError(e.message);
    }
  }, []);

  /* Loading screen */
  if (isS3Mode && status === "loading" && !rawData) {
    return <LoadingScreen />;
  }

  /* No data yet — show upload screen (admin) or waiting screen (team) */
  if (!rawData) {
    return (
      <NoDataScreen
        session={session} onLogout={onLogout}
        status={status} error={error}
        onRetry={fetchFromS3}
        onUpload={handleUpload}
        isS3Mode={isS3Mode}
      />
    );
  }

  return (
    <DashboardView
      rawData={rawData} uploadInfo={uploadInfo}
      loading={status==="loading"} session={session} onLogout={onLogout}
      onRefresh={isS3Mode ? fetchFromS3 : null}
      onUpload={handleUpload}
      selTenants={selTenants}       setSelTenants={setSelTenants}
      selConnectors={selConnectors} setSelConnectors={setSelConnectors}
      emailSearch={emailSearch}     setEmailSearch={setEmailSearch}
      dateRange={dateRange}         setDateRange={setDateRange}
    />
  );
}

/* ─── Loading screen ──────────────────────────────────────────── */
function LoadingScreen() {
  return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", background:"linear-gradient(135deg,#f0f4ff,#fafbff)", fontFamily:"DM Sans, sans-serif" }}>
      <div style={{ textAlign:"center" }}>
        <div style={{ width:60, height:60, borderRadius:18, background:"linear-gradient(135deg,#4f6ef7,#7c3aed)", display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 20px", boxShadow:"0 8px 32px rgba(79,110,247,0.28)" }}>
          <Cloud size={28} color="#fff" />
        </div>
        <div style={{ fontSize:20, fontWeight:800, color:"#1a2035", marginBottom:8 }}>Loading dashboard…</div>
        <div style={{ fontSize:13, color:"#8292b0", marginBottom:24 }}>Fetching shared data from S3</div>
        <div style={{ width:220, height:4, background:"#e8edf5", borderRadius:2, margin:"0 auto", overflow:"hidden" }}>
          <div style={{ height:"100%", background:"linear-gradient(90deg,#4f6ef7,#7c3aed)", borderRadius:2, width:"50%", animation:"sl 1.2s ease-in-out infinite" }} />
        </div>
        <style>{`@keyframes sl{0%{transform:translateX(-100%)}100%{transform:translateX(400%)}}`}</style>
      </div>
    </div>
  );
}

/* ─── No-data / error screen ──────────────────────────────────── */
function NoDataScreen({ session, onLogout, status, error, onRetry, onUpload, isS3Mode }) {
  const [file,         setFile]         = useState(null);
  const [presignedUrl, setPresignedUrl] = useState("");
  const [localUploading, setLocalUploading] = useState(false);
  const isAdmin = session.role === "Admin";
  const showManualUrlInput = isS3Mode && !hasAutoUpload;  // legacy fallback only

  const handleFileChange = (e) => setFile(e.target.files[0]);

  const handleSubmit = async () => {
    if (!file) return;
    setLocalUploading(true);
    await onUpload(file, isAdmin && showManualUrlInput ? presignedUrl : null);
    setLocalUploading(false);
  };

  return (
    <div style={{ minHeight:"100vh", background:"linear-gradient(135deg,#f0f4ff,#fafbff)", fontFamily:"DM Sans, sans-serif" }}>
      {/* Header */}
      <div style={{ background:"#fff", borderBottom:"1px solid #e8edf5", padding:"12px 24px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div style={{ fontSize:16, fontWeight:800, color:"#1a2035" }}><span style={{ color:"#4f6ef7" }}>API</span> Analytics · Aquera SRE</div>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:12, color:"#8292b0" }}>{session.name} · {session.title || session.role}</span>
          <button onClick={onLogout} style={{ background:"#f4f6fb", border:"1px solid #e8edf5", borderRadius:8, padding:"6px 12px", fontSize:11, cursor:"pointer", color:"#8292b0", display:"flex", alignItems:"center", gap:5 }}>
            <LogOut size={12} /> Sign out
          </button>
        </div>
      </div>

      <div style={{ display:"flex", alignItems:"center", justifyContent:"center", minHeight:"calc(100vh - 57px)", padding:24 }}>
        <div style={{ maxWidth:520, width:"100%" }}>

          {/* Error / retry */}
          {status === "error" && (
            <div style={{ background:"rgba(239,68,68,0.07)", border:"1px solid rgba(239,68,68,0.2)", borderRadius:14, padding:"16px 20px", marginBottom:20, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <div style={{ fontSize:13, color:"#dc2626" }}>⚠ {error}</div>
              <button onClick={onRetry} style={{ background:"#dc2626", border:"none", borderRadius:8, padding:"6px 14px", fontSize:12, color:"#fff", cursor:"pointer" }}>Retry</button>
            </div>
          )}

          {/* Non-admin waiting */}
          {!isAdmin && (
            <div style={{ background:"#fff", borderRadius:20, padding:"40px 36px", boxShadow:"0 8px 40px rgba(30,50,120,0.08)", border:"1px solid #e8edf5", textAlign:"center" }}>
              <div style={{ fontSize:40, marginBottom:16 }}>⏳</div>
              <h2 style={{ fontSize:22, fontWeight:800, color:"#1a2035", marginBottom:8 }}>Data not uploaded yet</h2>
              <p style={{ fontSize:14, color:"#8292b0", lineHeight:1.7, marginBottom:20 }}>
                An Admin needs to upload the latest Excel file.<br />Ask <strong style={{ color:"#1a2035" }}>Manikanta or Sravan Kumar</strong> to upload.
              </p>
              <button onClick={onRetry} style={{ background:"linear-gradient(135deg,#4f6ef7,#7c3aed)", border:"none", borderRadius:12, padding:"12px 28px", fontSize:13, fontWeight:700, color:"#fff", cursor:"pointer" }}>
                ↻ Check again
              </button>
            </div>
          )}

          {/* Admin upload card */}
          {isAdmin && (
            <div style={{ background:"#fff", borderRadius:20, padding:"36px 32px", boxShadow:"0 8px 40px rgba(30,50,120,0.08)", border:"1px solid #e8edf5" }}>
              <div style={{ marginBottom:24 }}>
                <h2 style={{ fontSize:22, fontWeight:800, color:"#1a2035", marginBottom:6 }}>Upload Dashboard Data</h2>
                <p style={{ fontSize:13, color:"#8292b0", lineHeight:1.6 }}>
                  {isS3Mode && hasAutoUpload
                    ? "Upload the Excel file — data saves to S3 automatically and the team sees it within ~1 minute."
                    : isS3Mode
                      ? "Upload Excel + provide a pre-signed URL → data saves to S3 → all team members see it automatically."
                      : "Upload your Excel file to view the dashboard."}
                </p>
              </div>

              {/* File picker */}
              <div style={{ marginBottom:16 }}>
                <label style={{ fontSize:11, fontWeight:700, color:"#8292b0", textTransform:"uppercase", letterSpacing:"0.08em", display:"block", marginBottom:6 }}>Excel File</label>
                <label style={{ display:"flex", alignItems:"center", gap:10, border:`2px dashed ${file ? "#10b981" : "#c5cfe0"}`, borderRadius:12, padding:"14px 16px", cursor:"pointer", background: file ? "rgba(16,185,129,0.04)" : "#f8faff" }}>
                  <input type="file" accept=".xlsx,.xls" onChange={handleFileChange} style={{ display:"none" }} />
                  <Upload size={18} color={file ? "#10b981" : "#8292b0"} />
                  <span style={{ fontSize:13, color: file ? "#10b981" : "#8292b0", fontWeight: file ? 600 : 400 }}>
                    {file ? `✓ ${file.name}` : "Click to select Excel file"}
                  </span>
                </label>
              </div>

              {/* Pre-signed URL (legacy fallback — hidden when auto-upload Lambda is configured) */}
              {showManualUrlInput && (
                <div style={{ marginBottom:20 }}>
                  <label style={{ fontSize:11, fontWeight:700, color:"#8292b0", textTransform:"uppercase", letterSpacing:"0.08em", display:"block", marginBottom:6 }}>
                    S3 Pre-signed URL <span style={{ fontWeight:400, color:"#c5cfe0" }}>(optional — needed to share with team)</span>
                  </label>
                  <input
                    value={presignedUrl} onChange={e => setPresignedUrl(e.target.value)}
                    placeholder="https://s3.amazonaws.com/...?X-Amz-Signature=..."
                    style={{ width:"100%", background:"#f4f6fb", border:"1.5px solid #e8edf5", borderRadius:10, padding:"10px 12px", fontSize:12, color:"#1a2035", outline:"none", fontFamily:"DM Mono, monospace", boxSizing:"border-box" }}
                  />
                  <div style={{ marginTop:8, padding:"10px 12px", background:"rgba(79,110,247,0.05)", borderRadius:8, border:"1px solid rgba(79,110,247,0.1)" }}>
                    <div style={{ fontSize:10, fontWeight:700, color:"#4f6ef7", marginBottom:4, textTransform:"uppercase" }}>Generate pre-signed URL (run once in terminal)</div>
                    <code style={{ fontSize:10, color:"#1a2035", lineHeight:1.8, display:"block" }}>
                      aws s3 presign s3://YOUR-BUCKET/dashboard-data.json \<br />
                      &nbsp;&nbsp;--expires-in 604800 --http-method PUT
                    </code>
                    <div style={{ fontSize:10, color:"#8292b0", marginTop:4 }}>Valid for 7 days. Regenerate weekly or after uploading.</div>
                  </div>
                </div>
              )}

              <button onClick={handleSubmit} disabled={!file || localUploading}
                style={{ width:"100%", background: !file ? "#e8edf5" : "linear-gradient(135deg,#4f6ef7,#7c3aed)", border:"none", borderRadius:12, padding:"13px", fontSize:14, fontWeight:700, color: !file ? "#8292b0" : "#fff", cursor: !file ? "not-allowed" : "pointer", transition:"all 0.15s" }}>
                {localUploading ? "Processing…" : isS3Mode ? "Upload & Share with Team →" : "Load Dashboard →"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─── Dashboard ───────────────────────────────────────────────── */
function DashboardView({ rawData, uploadInfo, loading, session, onLogout, onRefresh, onUpload, selTenants, setSelTenants, selConnectors, setSelConnectors, emailSearch, setEmailSearch, dateRange, setDateRange }) {
  const [page, setPage] = useState(() => readFiltersFromUrl().page);
  const [copiedShare, setCopiedShare] = useState(false);

  const allTenants    = useMemo(() => getUniqueTenants(rawData),    [rawData]);
  const allConnectors = useMemo(() => getUniqueConnectors(rawData), [rawData]);

  const filtered = useMemo(() => rawData.filter(r => {
    if (selTenants.length    && !selTenants.includes(r.tenantName))   return false;
    if (selConnectors.length && !selConnectors.includes(r.connector)) return false;
    if (emailSearch && !r.email?.toLowerCase().includes(emailSearch.toLowerCase())) return false;
    if (dateRange.start && r.date < dateRange.start) return false;
    if (dateRange.end   && r.date > dateRange.end)   return false;
    return true;
  }), [rawData, selTenants, selConnectors, emailSearch, dateRange]);

  // Sync filter state to URL so teammates can be sent shareable links
  useEffect(() => {
    writeFiltersToUrl({
      tenants: selTenants, connectors: selConnectors,
      email: emailSearch, start: dateRange.start, end: dateRange.end,
      page,
    });
  }, [selTenants, selConnectors, emailSearch, dateRange, page]);

  const metrics       = useMemo(() => computeKPIs(filtered),           [filtered]);
  const lastDayCalls  = useMemo(() => getLastDayCalls(filtered),        [filtered]);
  const last5Days     = useMemo(() => getLastNDaysCalls(filtered, 5),   [filtered]);
  const dailyTrend    = useMemo(() => getDailyTrend(filtered),          [filtered]);
  const monthlyTrend  = useMemo(() => getMonthlyTrend(filtered),        [filtered]);
  const topTenants    = useMemo(() => getTopTenants(filtered, 10),      [filtered]);
  const topConnectors = useMemo(() => getTopConnectors(filtered, 10),   [filtered]);
  const heatmap       = useMemo(() => getHeatmapData(filtered),         [filtered]);
  const tenantTable   = useMemo(() => getTenantTable(filtered),         [filtered]);
  const pivotData     = useMemo(() => getLast7DaysPivot(filtered),      [filtered]);
  const monthlyGraphs = useMemo(() => getMonthlyGraphData(filtered),    [filtered]);
  const tickerItems   = useMemo(() => getLast7DaysConnectors(filtered), [filtered]);
  const spikes        = useMemo(() => getTenantSpikes(filtered),        [filtered]);
  const wow           = useMemo(() => getTenantWoW(filtered),           [filtered]);

  const clearFilters = () => { setSelTenants([]); setSelConnectors([]); setEmailSearch(""); setDateRange({ start:"", end:"" }); };

  const copyShareLink = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 1500);
  };

  const NAV = [
    { key:"dashboard", label:"Dashboard",     Icon:LayoutDashboard },
    { key:"pivot",     label:"7-Day Pivot",   Icon:Table2 },
    { key:"monthly",   label:"Monthly",       Icon:BarChart2 },
    { key:"debug",     label:"Debug Guide",   Icon:LifeBuoy },
  ];

  return (
    <div style={{ display:"flex", minHeight:"100vh", fontFamily:"'DM Sans', sans-serif", background:"#f4f6fb" }}>
      <Sidebar
        onFileUpload={(e) => onUpload(e.target.files[0], null)}
        uploading={loading} uploadInfo={uploadInfo}
        allTenants={allTenants} allConnectors={allConnectors}
        selTenants={selTenants} selConnectors={selConnectors}
        emailSearch={emailSearch} dateRange={dateRange}
        onTenantChange={setSelTenants} onConnectorChange={setSelConnectors}
        onEmailChange={setEmailSearch} onDateChange={setDateRange}
        onClearFilters={clearFilters}
      />

      <div style={{ flex:1, display:"flex", flexDirection:"column", minWidth:0 }}>
        {/* Navbar */}
        <div style={{ background:"#fff", borderBottom:"1px solid #e8edf5", padding:"0 32px", display:"flex", justifyContent:"space-between", alignItems:"center", height:56, flexShrink:0 }}>
          <div style={{ display:"flex", gap:4, height:"100%" }}>
            {NAV.map(({ key, label, Icon }) => (
              <button key={key} onClick={() => setPage(key)}
                style={{ display:"flex", alignItems:"center", gap:7, padding:"0 16px", height:"100%", background:"none", border:"none", borderBottom: page===key ? "2px solid #4f6ef7" : "2px solid transparent", fontSize:13, fontWeight: page===key ? 700 : 500, color: page===key ? "#4f6ef7" : "#8292b0", cursor:"pointer", fontFamily:"DM Sans, sans-serif", whiteSpace:"nowrap" }}>
                <Icon size={14} /> {label}
              </button>
            ))}
          </div>

          <div style={{ display:"flex", alignItems:"center", gap:8 }}>
            {/* Share current view */}
            <button
              onClick={copyShareLink}
              title="Copy shareable link to this view"
              style={{ display:"flex", alignItems:"center", gap:5, background: copiedShare ? "rgba(16,185,129,0.1)" : "#f4f6fb", border:`1px solid ${copiedShare ? "rgba(16,185,129,0.3)" : "#e8edf5"}`, borderRadius:8, padding:"6px 10px", fontSize:11, fontWeight:600, color: copiedShare ? "#10b981" : "#8292b0", cursor:"pointer", fontFamily:"DM Sans, sans-serif" }}
            >
              <Share2 size={11} /> {copiedShare ? "Copied!" : "Share"}
            </button>
            {/* Cloud badge */}
            {uploadInfo?.cloudMode && (
              <div style={{ display:"flex", alignItems:"center", gap:5, fontSize:10, color:"#10b981", fontWeight:700, background:"rgba(16,185,129,0.08)", padding:"4px 10px", borderRadius:20 }}>
                <div style={{ width:5, height:5, borderRadius:"50%", background:"#10b981" }} /> Live
              </div>
            )}
            <div style={{ textAlign:"right" }}>
              <div style={{ fontSize:12, fontWeight:700, color:"#1a2035" }}>{session.name}</div>
              <div style={{ fontSize:10, color:"#8292b0" }}>{session.title || session.role}</div>
            </div>
            <div style={{ width:32, height:32, borderRadius:"50%", background:"linear-gradient(135deg,#4f6ef7,#7c3aed)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, fontWeight:800, color:"#fff" }}>
              {session.name[0].toUpperCase()}
            </div>
            {onRefresh && (
              <button onClick={onRefresh} disabled={loading} title="Refresh from S3"
                style={{ background:"#f4f6fb", border:"1px solid #e8edf5", borderRadius:8, width:32, height:32, display:"flex", alignItems:"center", justifyContent:"center", cursor: loading ? "wait" : "pointer" }}>
                <RefreshCw size={13} color={loading ? "#c5cfe0" : "#4f6ef7"} style={{ animation: loading ? "spin 1s linear infinite" : "none" }} />
              </button>
            )}
            <button onClick={onLogout} title="Sign out"
              style={{ background:"#f4f6fb", border:"1px solid #e8edf5", borderRadius:8, width:32, height:32, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
              <LogOut size={13} color="#8292b0" />
            </button>
          </div>
        </div>

        {/* Content */}
        <main style={{ flex:1, padding:"24px 32px", overflowY:"auto" }}>
          <div style={{ marginBottom:16, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div style={{ fontSize:11, color:"#8292b0" }}>
              {filtered.length.toLocaleString()} records
              {uploadInfo?.lastDate && <> · last date: <strong style={{ color:"#4f6ef7" }}>{uploadInfo.lastDate}</strong></>}
              {uploadInfo?.uploadedAt && <span style={{ marginLeft:8, color:"#c5cfe0" }}>· uploaded {new Date(uploadInfo.uploadedAt).toLocaleString()}</span>}
            </div>
          </div>

          {page === "dashboard" && (
            <>
              <ConnectorTicker connectors={tickerItems} />
              <Last5Days days={last5Days} />
              <ChartCard title="Last Day API Calls" style={{ marginBottom:16 }}>
                <div style={{ fontSize:42, fontWeight:800, letterSpacing:"-0.04em", color:"#1a2035", fontFamily:"'DM Mono', monospace" }}>{lastDayCalls.toLocaleString()}</div>
                {uploadInfo?.lastDate && <div style={{ fontSize:12, color:"#8292b0", marginTop:6 }}>Date: {uploadInfo.lastDate}</div>}
              </ChartCard>
              <KPICards metrics={{ ...metrics, lastDayCalls }} />
              <TrendChart daily={dailyTrend} monthly={monthlyTrend} />
              <div style={{ marginTop:20 }}><BreakdownCharts tenants={topTenants} connectors={topConnectors} /></div>
              <ChartCard title="Activity Heatmap" subtitle="Total API calls per tenant per day" style={{ marginTop:20 }}>
                <Heatmap data={heatmap} />
              </ChartCard>
              <TenantTable tenants={tenantTable} totalCalls={metrics.totalCalls} spikes={spikes} wow={wow} />
            </>
          )}

          {page === "pivot" && (
            <div style={{ background:"#fff", borderRadius:16, border:"1px solid #e8edf5", overflow:"hidden" }}>
              <div style={{ padding:"20px 24px 16px", borderBottom:"1px solid #e8edf5" }}>
                <div style={{ fontSize:16, fontWeight:800, color:"#1a2035" }}>Last 7 Days — Pivot Table</div>
                <div style={{ fontSize:11, color:"#8292b0", marginTop:3 }}>Daily calls per tenant · click headers to sort</div>
              </div>
              <div style={{ padding:"16px 24px 24px" }}><PivotTable data={pivotData} /></div>
            </div>
          )}

          {page === "monthly" && (
            <div style={{ background:"#fff", borderRadius:16, border:"1px solid #e8edf5", overflow:"hidden" }}>
              <div style={{ padding:"20px 24px 16px", borderBottom:"1px solid #e8edf5" }}>
                <div style={{ fontSize:16, fontWeight:800, color:"#1a2035" }}>Monthly API Consumption</div>
                <div style={{ fontSize:11, color:"#8292b0", marginTop:3 }}>Click any month bar to drill into daily view</div>
              </div>
              <div style={{ padding:"20px 24px 28px" }}><MonthlyGraphs months={monthlyGraphs} /></div>
            </div>
          )}

          {page === "debug" && <DebugPage />}

          <div style={{ marginTop:20, fontSize:10, color:"#c5cfe0", textAlign:"center" }}>Aquera API Analytics · Team SRE</div>
        </main>
      </div>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
