import React from "react";
import { AlertTriangle, Search, Wrench, Phone, ExternalLink, CheckCircle2 } from "lucide-react";

/**
 * Debug Page
 * ==========
 * A static content page that walks the team through debugging which tenant /
 * connector is making excess API calls and how to resolve it.
 *
 * ⚠️  REPLACE THE `TODO:` BLOCKS BELOW with your own content. The structure
 * (sections, headers, colors) is pre-styled and matches the rest of the
 * dashboard — you only need to fill in the actual debugging steps.
 */

const T = {
  bg: "#f4f6fb",
  card: "#fff",
  border: "#e8edf5",
  text: "#1a2035",
  muted: "#8292b0",
  accent: "#4f6ef7",
  warn: "#f59e0b",
  danger: "#ef4444",
  success: "#10b981",
};

function Section({ icon: Icon, title, accent = T.accent, children }) {
  return (
    <div
      style={{
        background: T.card,
        borderRadius: 16,
        border: `1px solid ${T.border}`,
        padding: "24px 28px",
        marginBottom: 20,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
        <div
          style={{
            width: 40,
            height: 40,
            borderRadius: 10,
            background: `${accent}15`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Icon size={20} color={accent} />
        </div>
        <div style={{ fontSize: 17, fontWeight: 800, color: T.text, letterSpacing: "-0.02em" }}>
          {title}
        </div>
      </div>
      <div style={{ fontSize: 13.5, color: T.text, lineHeight: 1.7 }}>{children}</div>
    </div>
  );
}

function Step({ num, title, children }) {
  return (
    <div style={{ display: "flex", gap: 14, marginBottom: 18 }}>
      <div
        style={{
          flexShrink: 0,
          width: 28,
          height: 28,
          borderRadius: "50%",
          background: "linear-gradient(135deg,#4f6ef7,#7c3aed)",
          color: "#fff",
          fontSize: 13,
          fontWeight: 800,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {num}
      </div>
      <div style={{ flex: 1, paddingTop: 2 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: T.text, marginBottom: 4 }}>{title}</div>
        <div style={{ fontSize: 13, color: T.muted, lineHeight: 1.7 }}>{children}</div>
      </div>
    </div>
  );
}

function CodeBlock({ children }) {
  return (
    <pre
      style={{
        background: "#1a2035",
        color: "#c5cfe0",
        borderRadius: 8,
        padding: "12px 14px",
        fontSize: 12,
        fontFamily: "'DM Mono', Consolas, monospace",
        overflowX: "auto",
        margin: "8px 0",
      }}
    >
      {children}
    </pre>
  );
}

function Callout({ type = "info", children }) {
  const config = {
    info: { bg: "rgba(79,110,247,0.07)", border: "rgba(79,110,247,0.25)", color: T.accent, icon: "💡" },
    warn: { bg: "rgba(245,158,11,0.08)", border: "rgba(245,158,11,0.3)", color: T.warn, icon: "⚠️" },
    danger: { bg: "rgba(239,68,68,0.07)", border: "rgba(239,68,68,0.25)", color: T.danger, icon: "🚨" },
    success: { bg: "rgba(16,185,129,0.08)", border: "rgba(16,185,129,0.25)", color: T.success, icon: "✅" },
  }[type];
  return (
    <div
      style={{
        background: config.bg,
        border: `1px solid ${config.border}`,
        borderRadius: 10,
        padding: "12px 14px",
        margin: "12px 0",
        fontSize: 13,
        color: T.text,
        display: "flex",
        gap: 10,
      }}
    >
      <span style={{ flexShrink: 0 }}>{config.icon}</span>
      <div style={{ flex: 1, lineHeight: 1.6 }}>{children}</div>
    </div>
  );
}

export default function DebugPage() {
  return (
    <div style={{ maxWidth: 920 }}>
      {/* Hero */}
      <div
        style={{
          background: "linear-gradient(135deg,#4f6ef7,#7c3aed)",
          borderRadius: 16,
          padding: "28px 32px",
          color: "#fff",
          marginBottom: 24,
        }}
      >
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", opacity: 0.85, marginBottom: 6 }}>
          Runbook
        </div>
        <h1 style={{ fontSize: 26, fontWeight: 900, letterSpacing: "-0.03em", margin: "0 0 8px" }}>
          Debugging High API Calls
        </h1>
        <p style={{ fontSize: 14, opacity: 0.92, margin: 0, lineHeight: 1.6 }}>
          Step-by-step guide for identifying which tenant or connector is
          driving a spike, investigating the root cause, and remediating.
        </p>
      </div>

      {/* Symptoms */}
      <Section icon={AlertTriangle} title="When to start debugging" accent={T.warn}>
        <p style={{ marginTop: 0 }}>
          Open this runbook when any of the following happens:
        </p>
        <ul style={{ paddingLeft: 20, margin: "8px 0" }}>
          <li>A tenant shows a 🚨 <strong>SPIKE</strong> badge on the dashboard or in the weekly Slack post</li>
          <li>Total daily API calls jump &gt;50% day-over-day</li>
          <li>A customer/tenant reports slow performance or hits a rate limit</li>
          <li>ADP flags unusual traffic from our connector</li>
        </ul>

        {/* TODO: Replace with your team's specific triggers / thresholds */}
        <Callout type="warn">
          <strong>TODO:</strong> Add any internal thresholds, SLAs, or customer-specific rules
          your team uses to decide when to investigate.
        </Callout>
      </Section>

      {/* Investigation */}
      <Section icon={Search} title="Step-by-step investigation" accent={T.accent}>
        <Step num={1} title="Identify the tenant and connector">
          On the <strong>Dashboard</strong> tab, look at the <em>Last 5 Days</em> cards and the
          <em> Activity Heatmap</em>. Sort the tenant table by <strong>Calls</strong> and note
          the top 3 tenants with spike badges.
          <br />
          Cross-reference with the <strong>7-Day Pivot</strong> tab to see which day(s) the
          spike started.
        </Step>

        <Step num={2} title="Narrow down to the connector">
          In the sidebar, apply a <strong>Tenant filter</strong> for the suspect tenant. The
          <em> Connector breakdown</em> chart now shows which connector(s) are responsible.
          Usually one connector dominates.
        </Step>

        <Step num={3} title="Check for recent config changes">
          {/* TODO: Replace with the exact place to check — e.g., Aquera admin panel, customer OID lookup */}
          <Callout type="info">
            <strong>TODO:</strong> Document how to check recent config changes for a tenant —
            e.g., "Go to Aquera Admin &gt; Tenants &gt; [OID] &gt; Config History".
          </Callout>
        </Step>

        <Step num={4} title="Pull logs for the spike window">
          {/* TODO: Replace with your log query */}
          <CodeBlock>
{`# TODO: Replace with your actual log query
# Example CloudWatch Insights query:
fields @timestamp, tenantId, connector, endpoint, statusCode
| filter tenantId = "<OID>"
| filter @timestamp > <spike_start>
| stats count() by connector, endpoint
| sort count desc`}
          </CodeBlock>
        </Step>

        <Step num={5} title="Classify the cause">
          Based on logs, the spike usually falls into one of these buckets:
          <ul style={{ paddingLeft: 20, marginTop: 6 }}>
            <li><strong>Retry storm</strong> — customer's system is retrying failed calls without backoff</li>
            <li><strong>Polling loop</strong> — new/misconfigured sync running more often than scheduled</li>
            <li><strong>Backfill</strong> — legitimate one-time bulk sync (e.g., onboarding, data migration)</li>
            <li><strong>Bug in our code</strong> — a recent release introduced extra calls per operation</li>
            <li><strong>Customer scale-up</strong> — real growth in customer's underlying data</li>
          </ul>
        </Step>
      </Section>

      {/* Remediation */}
      <Section icon={Wrench} title="Remediation playbook" accent={T.success}>
        {/* TODO: Replace with your team's actual remediation steps */}
        <Callout type="info">
          <strong>TODO:</strong> Fill in the steps your team takes for each cause category above.
          Below is a starter template — rewrite with your real procedures.
        </Callout>

        <div style={{ marginTop: 12 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: T.text, marginBottom: 6 }}>
            Retry storm / polling loop
          </div>
          <ul style={{ paddingLeft: 20, margin: "0 0 14px", color: T.muted, lineHeight: 1.7 }}>
            <li>TODO: How to engage the customer (template email, Slack channel, etc.)</li>
            <li>TODO: How to temporarily throttle the tenant if needed</li>
            <li>TODO: Link to rate-limiting configuration docs</li>
          </ul>

          <div style={{ fontSize: 14, fontWeight: 700, color: T.text, marginBottom: 6 }}>
            Backfill / legitimate traffic
          </div>
          <ul style={{ paddingLeft: 20, margin: "0 0 14px", color: T.muted, lineHeight: 1.7 }}>
            <li>TODO: How to confirm with customer and document the expected end date</li>
            <li>TODO: How to suppress future SPIKE alerts for this tenant</li>
          </ul>

          <div style={{ fontSize: 14, fontWeight: 700, color: T.text, marginBottom: 6 }}>
            Our bug
          </div>
          <ul style={{ paddingLeft: 20, margin: 0, color: T.muted, lineHeight: 1.7 }}>
            <li>TODO: How to create an incident / JIRA ticket</li>
            <li>TODO: Rollback / hotfix process</li>
          </ul>
        </div>
      </Section>

      {/* Escalation */}
      <Section icon={Phone} title="Escalation contacts" accent={T.danger}>
        {/* TODO: Replace with real contacts */}
        <Callout type="danger">
          <strong>TODO:</strong> Replace these placeholders with actual names, Slack handles,
          and phone numbers.
        </Callout>

        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 8, fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: `2px solid ${T.border}`, textAlign: "left" }}>
              <th style={{ padding: "8px 10px", color: T.muted, fontWeight: 700, fontSize: 11, textTransform: "uppercase" }}>Role</th>
              <th style={{ padding: "8px 10px", color: T.muted, fontWeight: 700, fontSize: 11, textTransform: "uppercase" }}>Contact</th>
              <th style={{ padding: "8px 10px", color: T.muted, fontWeight: 700, fontSize: 11, textTransform: "uppercase" }}>When to escalate</th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ borderBottom: `1px solid ${T.border}` }}>
              <td style={{ padding: "10px", fontWeight: 600 }}>On-call SRE</td>
              <td style={{ padding: "10px", color: T.muted }}>TODO: @handle · #channel</td>
              <td style={{ padding: "10px", color: T.muted }}>P1 / customer-impacting</td>
            </tr>
            <tr style={{ borderBottom: `1px solid ${T.border}` }}>
              <td style={{ padding: "10px", fontWeight: 600 }}>Engineering lead</td>
              <td style={{ padding: "10px", color: T.muted }}>TODO: @handle</td>
              <td style={{ padding: "10px", color: T.muted }}>Suspected bug in our code</td>
            </tr>
            <tr>
              <td style={{ padding: "10px", fontWeight: 600 }}>Customer success</td>
              <td style={{ padding: "10px", color: T.muted }}>TODO: @handle</td>
              <td style={{ padding: "10px", color: T.muted }}>Customer-facing communication</td>
            </tr>
          </tbody>
        </table>
      </Section>

      {/* Useful links */}
      <Section icon={ExternalLink} title="Useful links" accent={T.accent}>
        {/* TODO: Replace with your actual internal URLs */}
        <ul style={{ paddingLeft: 20, margin: 0, lineHeight: 2 }}>
          <li>TODO: Link to Aquera admin panel</li>
          <li>TODO: Link to CloudWatch / log dashboard</li>
          <li>TODO: Link to ADP connector documentation</li>
          <li>TODO: Link to customer runbook / support portal</li>
          <li>TODO: Link to rate-limiting / quota configuration</li>
        </ul>
      </Section>

      {/* Post-mortem */}
      <Section icon={CheckCircle2} title="After resolution" accent={T.success}>
        <ul style={{ paddingLeft: 20, margin: 0, lineHeight: 1.9 }}>
          <li>Add a short note to the weekly Slack thread explaining what happened</li>
          <li>If the root cause was a bug, file a post-mortem within 48 hours</li>
          <li>If the same tenant spikes 3+ times in a month, schedule a call with customer success</li>
          {/* TODO: Add any other post-resolution steps */}
        </ul>
      </Section>

      <div style={{ textAlign: "center", fontSize: 11, color: "#c5cfe0", padding: "20px 0" }}>
        Last updated: <span style={{ color: T.muted }}>TODO: add date</span> · Maintained by Team SRE
      </div>
    </div>
  );
}
