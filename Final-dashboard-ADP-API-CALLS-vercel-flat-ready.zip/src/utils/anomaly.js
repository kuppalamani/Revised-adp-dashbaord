/**
 * Anomaly Detection
 * =================
 * Flags tenants whose most recent API-call volume is significantly higher
 * than their rolling baseline. Used to highlight "who spiked" on the
 * tenant table and to populate the Slack weekly alert.
 */

const DEFAULT_SPIKE_THRESHOLD = 3.0; // last-day >= 3x prior-7-day avg → spike
const DEFAULT_MIN_CALLS = 100;       // ignore tiny-volume tenants to reduce noise

/**
 * Build { tenantName → { lastDayCalls, avg7, ratio, isSpike } } map.
 *
 * @param {Array} records — flat records from dataProcessor
 * @param {Object} opts
 * @param {number} opts.spikeThreshold
 * @param {number} opts.minCalls
 */
export function getTenantSpikes(records = [], opts = {}) {
  const threshold = opts.spikeThreshold ?? DEFAULT_SPIKE_THRESHOLD;
  const minCalls = opts.minCalls ?? DEFAULT_MIN_CALLS;

  if (!records.length) return {};

  const allDates = [...new Set(records.map((r) => r.date))].sort();
  if (allDates.length < 2) return {};

  const lastDay = allDates[allDates.length - 1];
  // Prior window: up to 7 days before the last day
  const priorStart = Math.max(0, allDates.length - 8);
  const priorEnd = allDates.length - 1; // exclusive
  const priorDates = new Set(allDates.slice(priorStart, priorEnd));

  const lastByTenant = {};
  const priorByTenant = {};
  const priorDaysSeenByTenant = {};

  records.forEach((r) => {
    const t = r.tenantName;
    if (!t) return;
    if (r.date === lastDay) {
      lastByTenant[t] = (lastByTenant[t] || 0) + r.calls;
    } else if (priorDates.has(r.date)) {
      priorByTenant[t] = (priorByTenant[t] || 0) + r.calls;
      if (!priorDaysSeenByTenant[t]) priorDaysSeenByTenant[t] = new Set();
      priorDaysSeenByTenant[t].add(r.date);
    }
  });

  const out = {};
  Object.entries(lastByTenant).forEach(([tenant, lastDayCalls]) => {
    const priorTotal = priorByTenant[tenant] || 0;
    const priorDays = priorDaysSeenByTenant[tenant]?.size || 0;
    const avg7 = priorDays > 0 ? priorTotal / priorDays : 0;
    const ratio = avg7 > 0 ? lastDayCalls / avg7 : null;
    const isSpike =
      lastDayCalls >= minCalls && avg7 > 0 && ratio >= threshold;
    out[tenant] = { lastDayCalls, avg7: Math.round(avg7), ratio, isSpike };
  });

  return out;
}

/**
 * Week-over-week comparison for the tenant table.
 * Returns { tenantName → { last7, prev7, pct } }
 */
export function getTenantWoW(records = []) {
  if (!records.length) return {};
  const allDates = [...new Set(records.map((r) => r.date))].sort();
  const last7 = new Set(allDates.slice(-7));
  const prev7 = new Set(allDates.slice(-14, -7));

  const lastMap = {};
  const prevMap = {};
  records.forEach((r) => {
    if (!r.tenantName) return;
    if (last7.has(r.date)) lastMap[r.tenantName] = (lastMap[r.tenantName] || 0) + r.calls;
    else if (prev7.has(r.date)) prevMap[r.tenantName] = (prevMap[r.tenantName] || 0) + r.calls;
  });

  const out = {};
  Object.keys(lastMap).forEach((t) => {
    const cur = lastMap[t] || 0;
    const prev = prevMap[t] || 0;
    let pct = null;
    if (prev > 0) pct = Math.round(((cur - prev) / prev) * 100);
    out[t] = { last7: cur, prev7: prev, pct };
  });
  return out;
}
