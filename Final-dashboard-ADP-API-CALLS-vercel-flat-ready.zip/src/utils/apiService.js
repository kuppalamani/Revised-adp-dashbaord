/**
 * Aquera API Service
 *
 * When REACT_APP_API_URL is set (production on AWS), fetches data from Lambda.
 * When not set (local dev), falls back to local Excel file upload.
 */

const API_URL = process.env.REACT_APP_API_URL;

export const isCloudMode = !!API_URL;

/**
 * Fetch parsed data from Lambda API
 * Returns { meta, records } matching parseExcelFile output shape
 */
export async function fetchDataFromAPI() {
  if (!API_URL) throw new Error("No API URL configured — use local upload mode");

  const res = await fetch(`${API_URL}/data`, {
    method: "GET",
    headers: { "Content-Type": "application/json" },
    // 30s timeout
    signal: AbortSignal.timeout(30000),
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `API error ${res.status}`);
  }

  const json = await res.json();

  // Validate shape
  if (!json.records || !Array.isArray(json.records)) {
    throw new Error("Invalid API response — no records array");
  }

  return {
    data:          json.records,
    sheetName:     json.meta?.sheetName     ?? "API",
    totalRows:     json.meta?.totalRows     ?? json.records.length,
    dateColsCount: json.meta?.dateColsCount ?? 0,
    allDates:      json.meta?.allDates      ?? [],
    lastDate:      json.meta?.lastDate      ?? null,
    parsedAt:      json.meta?.parsedAt      ?? new Date().toISOString(),
  };
}

/**
 * Check API health
 */
export async function checkAPIHealth() {
  if (!API_URL) return { ok: false, reason: "No API URL" };
  try {
    const res = await fetch(`${API_URL}/health`, { signal: AbortSignal.timeout(5000) });
    const body = await res.json();
    return { ok: res.ok, ...body };
  } catch (e) {
    return { ok: false, reason: e.message };
  }
}
