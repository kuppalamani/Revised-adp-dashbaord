/**
 * User directory + local login.
 *
 * Each user has:
 *   username  — email
 *   password  — plaintext (temporary; proper auth with hashing + backend coming soon)
 *   name      — display name
 *   role      — "Admin" (can upload) or "Operations" (view-only)
 *   title     — display title shown next to name on dashboard (e.g. "Team Lead",
 *               "Director of Engineering"). Falls back to `role` if omitted.
 */

const USERS = [
  // ── Admins (upload permission) ──────────────────────────────────
  { username: "manikanta.kuppala@aquera.com",         password: "Mani@1997",    name: "Manikanta",    role: "Admin",      title: "Admin" },
  { username: "illuri.sravankumar@aquera.com",        password: "SravanKumar",  name: "Sravan Kumar", role: "Admin",      title: "Admin" },

  // ── Operations / view-only ──────────────────────────────────────
  { username: "vikash.kumar@aquera.com",              password: "Vikash@123",   name: "Vikash",       role: "Operations", title: "Director of Engineering" },
  { username: "pavan.kumar@aquera.com",               password: "Pavan@123",    name: "Pavan",        role: "Operations", title: "Manager" },
  { username: "sabarinathan.chidhambaram@aquera.com", password: "Sabari@123",   name: "Sabarinathan", role: "Operations", title: "Team Lead" },
  { username: "shivasharan.kumbar@aquera.com",        password: "Shiva@123",    name: "Shivasharan",  role: "Operations", title: "SRE" },
  { username: "anil.kasagar@aquera.com",              password: "Anil@123",     name: "Anil",         role: "Operations", title: "Operations" },
  { username: "golla.ramudu@aquera.com",              password: "Ramudu@123",   name: "Ramudu",       role: "Operations", title: "Operations" },
  { username: "naveen.maraiah@aquera.com",            password: "Naveen@123",   name: "Naveen",       role: "Operations", title: "Operations" },
  { username: "raghu.chitragar@aquera.com",           password: "Raghu@123",    name: "Raghu",        role: "Operations", title: "Operations" },
  { username: "rishabh.tiwari@aquera.com",            password: "Rishab@123",   name: "Rishabh",      role: "Operations", title: "Operations" },
  { username: "vasanth.kumar@aquera.com",             password: "Vasanth@123",  name: "Vasanth",      role: "Operations", title: "Operations" },
];

const SESSION_KEY = "aquera_session";

export function login(username, password) {
  // Case-insensitive username match, case-sensitive password
  const needle = String(username || "").trim().toLowerCase();
  const user = USERS.find(
    (u) => u.username.toLowerCase() === needle && u.password === password
  );
  if (!user) return { ok: false, error: "Invalid username or password." };
  const session = {
    name: user.name,
    role: user.role,
    title: user.title || user.role,
    username: user.username,
    loginAt: Date.now(),
  };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return { ok: true, user: session };
}

export function logout() {
  sessionStorage.removeItem(SESSION_KEY);
}

export function getSession() {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}
