/**
 * CSV Export Helper
 * =================
 * Converts an array of objects (or 2D rows) into a downloadable CSV file.
 */

function escapeCell(v) {
  if (v === null || v === undefined) return "";
  const s = String(v);
  // If contains comma, quote, or newline — wrap in quotes and escape internal quotes
  if (/[",\n\r]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

/**
 * Export array of objects as CSV.
 * @param {Array<Object>} rows
 * @param {Array<{key: string, label: string}>} columns — column definitions (order matters)
 * @param {string} filename — e.g. "tenants-2024-11-20.csv"
 */
export function exportRowsAsCsv(rows, columns, filename = "export.csv") {
  if (!Array.isArray(rows) || !rows.length) {
    alert("Nothing to export.");
    return;
  }
  const header = columns.map((c) => escapeCell(c.label)).join(",");
  const body = rows
    .map((row) => columns.map((c) => escapeCell(row[c.key])).join(","))
    .join("\n");
  const csv = header + "\n" + body;
  downloadCsv(csv, filename);
}

/**
 * Export a pre-built 2D matrix as CSV (first row = header).
 */
export function exportMatrixAsCsv(matrix, filename = "export.csv") {
  if (!matrix?.length) {
    alert("Nothing to export.");
    return;
  }
  const csv = matrix.map((row) => row.map(escapeCell).join(",")).join("\n");
  downloadCsv(csv, filename);
}

function downloadCsv(csvString, filename) {
  // Prepend BOM so Excel opens UTF-8 correctly
  const blob = new Blob(["\uFEFF" + csvString], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function todayStamp() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
