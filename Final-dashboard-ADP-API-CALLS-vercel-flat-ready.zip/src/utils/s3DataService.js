/**
 * S3 Data Service
 * ================
 * Fetch shared dashboard data (team members) and upload new data (admin).
 *
 * Flow:
 *   1. Team members:  GET  ${S3_DATA_URL}         → JSON records
 *   2. Admin uploads: POST ${UPLOAD_URL_ENDPOINT} → get short-lived pre-signed URL
 *                     PUT  that URL with new JSON → S3 updated
 *
 * Env vars (set in .env before `npm run build`):
 *   REACT_APP_S3_DATA_URL         Public URL of dashboard-data.json
 *   REACT_APP_UPLOAD_URL_ENDPOINT API Gateway URL of the get_upload_url Lambda
 *                                 (optional — if unset, falls back to manual
 *                                  paste-a-URL flow)
 *   REACT_APP_ADMIN_SECRET        Shared secret sent to the Lambda so only
 *                                 admins can generate upload URLs
 */

export const S3_DATA_URL = process.env.REACT_APP_S3_DATA_URL;
export const UPLOAD_URL_ENDPOINT = process.env.REACT_APP_UPLOAD_URL_ENDPOINT;
export const ADMIN_SECRET = process.env.REACT_APP_ADMIN_SECRET;

export const isS3Mode = !!S3_DATA_URL;
export const hasAutoUpload = !!(UPLOAD_URL_ENDPOINT && ADMIN_SECRET);

/**
 * Fetch shared dashboard data from S3 (all team members call this).
 */
export async function fetchSharedData() {
  if (!S3_DATA_URL) throw new Error("REACT_APP_S3_DATA_URL not set");

  const url = `${S3_DATA_URL}?v=${Date.now()}`;
  const res = await fetch(url, { cache: "no-store" });

  if (res.status === 404) throw new Error("NO_DATA");
  if (!res.ok) throw new Error(`Failed to load data (${res.status})`);

  const json = await res.json();
  if (!json.records || !Array.isArray(json.records)) {
    throw new Error("Invalid data format in S3");
  }
  // Treat empty-records placeholder as no-data
  if (json.records.length === 0) throw new Error("NO_DATA");
  return json;
}

/**
 * Request a fresh pre-signed PUT URL from the Lambda.
 * (Only admins should be triggering this — the Lambda validates the secret.)
 */
export async function requestUploadUrl() {
  if (!hasAutoUpload) {
    throw new Error("Auto-upload not configured. Set REACT_APP_UPLOAD_URL_ENDPOINT and REACT_APP_ADMIN_SECRET.");
  }
  const res = await fetch(UPLOAD_URL_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Admin-Secret": ADMIN_SECRET,
    },
  });
  if (res.status === 401) throw new Error("Admin secret rejected by server.");
  if (!res.ok) throw new Error(`Failed to get upload URL (${res.status})`);
  const { url } = await res.json();
  return url;
}

/**
 * Upload parsed data to S3 as JSON using a pre-signed PUT URL.
 * Call requestUploadUrl() first to get the URL.
 */
export async function uploadDataToS3(records, meta, presignedUrl) {
  if (!presignedUrl) throw new Error("No pre-signed URL provided");

  const payload = {
    records,
    meta: { ...meta, uploadedAt: new Date().toISOString() },
  };

  const res = await fetch(presignedUrl, {
    method: "PUT",
    headers: { "Content-Type": "application/json",
               "Cache-Control": "public, max-age=60", },
    body: JSON.stringify(payload),
   
  });

  if (!res.ok) {
    throw new Error(`Upload failed (${res.status}). Pre-signed URL may have expired.`);
  }
  return true;
}
